<!--
title: Tencent Cloud - Serverless Cloud Function (SCF) - Guide
menuText: Guide
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/tencent/guide/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Tencent SCF Guide

Welcome to the Serverless Tencent SCF Guide!

Get started with the [Introduction to the framework](./intro.md)

If you have questions, join the [chat in Slack](https://serverless.com/slack) or [post over on the forums](https://forum.serverless.com/)
