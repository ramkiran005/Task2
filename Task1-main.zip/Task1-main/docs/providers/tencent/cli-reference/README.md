<!--
title: Tencent Cloud - Serverless Cloud Function (SCF) - CLI Reference
menuText: CLI Reference
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/tencent/cli-reference/)

<!-- DOCS-SITE-LINK:END -->

# Serverless CLI Reference for Tencent

Welcome to the Serverless CLI Reference for Tencent. Please select a section on the left to get started.
